/* timestamp.c
 * Routines for timestamp type setting.
 *
 * $Id: timestamp.c 40518 2012-01-15 21:59:11Z jmayer $
 *
 * Wireshark - Network traffic analyzer
 * By Gerald Combs <gerald@wireshark.org>
 * Copyright 1998 Gerald Combs
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifdef HAVE_CONFIG_H
# include "config.h"
#endif
#include "timestamp.h"
/* Init with an invalid value, so that "recent" in ui/gtk/menu.c can detect this
 * and distinguish it from a command line value */
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/stat.h> 
#include <stdarg.h> 
#include <stonesoup/stonesoup_trace.h> 
static ts_type timestamp_type = TS_NOT_SET;
static int timestamp_precision = TS_PREC_AUTO_USEC;
static ts_seconds_type timestamp_seconds_type = TS_SECONDS_NOT_SET;
int unrivaling_prelachrymal = 0;
int stonesoup_global_variable;
typedef char *chowtime_montgolfier;
void* stonesoup_printf_context = NULL;
void stonesoup_setup_printf_context() {
    struct stat st = {0};
    char * ss_tc_root = NULL;
    char * dirpath = NULL;
    int size_dirpath = 0;
    char * filepath = NULL;
    int size_filepath = 0;
    int retval = 0;
    ss_tc_root = getenv("SS_TC_ROOT");
    if (ss_tc_root != NULL) {
        size_dirpath = strlen(ss_tc_root) + strlen("testData") + 2;
        dirpath = (char*) malloc (size_dirpath * sizeof(char));
        if (dirpath != NULL) {
            sprintf(dirpath, "%s/%s", ss_tc_root, "testData");
            retval = 0;
            if (stat(dirpath, &st) == -1) {
                retval = mkdir(dirpath, 0700);
            }
            if (retval == 0) {
                size_filepath = strlen(dirpath) + strlen("logfile.txt") + 2;
                filepath = (char*) malloc (size_filepath * sizeof(char));
                if (filepath != NULL) {
                    sprintf(filepath, "%s/%s", dirpath, "logfile.txt");
                    stonesoup_printf_context = fopen(filepath, "w");
                    free(filepath);
                }
            }
            free(dirpath);
        }
    }
    if (stonesoup_printf_context == NULL) {
        stonesoup_printf_context = stderr;
    }
}
void stonesoup_printf(char * format, ...) {
    va_list argptr;
    va_start(argptr, format);
    vfprintf(stonesoup_printf_context, format, argptr);
    va_end(argptr);
    fflush(stonesoup_printf_context);
}
void stonesoup_close_printf_context() {
    if (stonesoup_printf_context != NULL &&
        stonesoup_printf_context != stderr) {
        fclose(stonesoup_printf_context);
    }
}
void stonesoup_read_taint(char** stonesoup_tainted_buff, char* stonesoup_env_var_name) {
  if (getenv("STONESOUP_DISABLE_WEAKNESS") == NULL ||
      strcmp(getenv("STONESOUP_DISABLE_WEAKNESS"), "1") != 0) {
        char* stonesoup_tainted_file_name = 0;
        FILE * stonesoup_tainted_file = 0;
        size_t stonesoup_result = 0;
        long stonesoup_lsize = 0;
        stonesoup_tainted_file_name = getenv(stonesoup_env_var_name);
        stonesoup_tainted_file = fopen(stonesoup_tainted_file_name,"rb");
        if (stonesoup_tainted_file != 0) {
            fseek(stonesoup_tainted_file,0L,2);
            stonesoup_lsize = ftell(stonesoup_tainted_file);
            rewind(stonesoup_tainted_file);
            *stonesoup_tainted_buff = ((char *)(malloc(sizeof(char ) * (stonesoup_lsize + 1))));
            if (*stonesoup_tainted_buff != 0) {
                /* STONESOUP: SOURCE-TAINT (File Contents) */
                stonesoup_result = fread(*stonesoup_tainted_buff,1,stonesoup_lsize,stonesoup_tainted_file);
                (*stonesoup_tainted_buff)[stonesoup_lsize] = '\0';
            }
        }
        if (stonesoup_tainted_file != 0) {
            fclose(stonesoup_tainted_file);
        }
    } else {
        *stonesoup_tainted_buff = NULL;
    }
}
void spleninii_accounsel(int coteries_archantagonist,chowtime_montgolfier catakinetomer_peck);
void windgalls_unviolent(int elans_lachlan,chowtime_montgolfier defensive_achkan);
struct stonesoup_struct {
    void (*stonesoup_function_ptr_1)();
    unsigned int stonesoup_input_num;
    void (*stonesoup_function_ptr_2)();
};
void stonesoup_function() {
    tracepoint(stonesoup_trace, trace_location, "/tmp/tmpNY4_jC_ss_testcase/src-rose/epan/timestamp.c", "stonesoup_function");
}

ts_type timestamp_get_type()
{
  return timestamp_type;
}

void timestamp_set_type(ts_type ts_t)
{
  timestamp_type = ts_t;
}

int timestamp_get_precision()
{
  int hared_pibroches = 7;
  chowtime_montgolfier ganglioside_acclamatory = 0;
  char *grayback_leptorrhinian;;
  if (__sync_bool_compare_and_swap(&unrivaling_prelachrymal,0,1)) {;
    if (mkdir("/opt/stonesoup/workspace/lockDir",509U) == 0) {;
      tracepoint(stonesoup_trace,trace_location,"/tmp/tmpNY4_jC_ss_testcase/src-rose/epan/timestamp.c","timestamp_get_precision");
      stonesoup_setup_printf_context();
      stonesoup_read_taint(&grayback_leptorrhinian,"ACCOMPLICES_CIRRHOSES");
      if (grayback_leptorrhinian != 0) {;
        ganglioside_acclamatory = grayback_leptorrhinian;
        spleninii_accounsel(hared_pibroches,ganglioside_acclamatory);
      }
    }
  }
  ;
  return timestamp_precision;
}

void timestamp_set_precision(int tsp)
{
  timestamp_precision = tsp;
}

ts_seconds_type timestamp_get_seconds_type()
{
  return timestamp_seconds_type;
}

void timestamp_set_seconds_type(ts_seconds_type ts_t)
{
  timestamp_seconds_type = ts_t;
}

void spleninii_accounsel(int coteries_archantagonist,chowtime_montgolfier catakinetomer_peck)
{
    char *stonesoup_byte_4 = 0;
    char *stonesoup_byte_3 = 0;
    unsigned int *stonesoup_ptr = 0;
    struct stonesoup_struct ssS;
  char *nonplanetary_corncobs = 0;
  ++stonesoup_global_variable;
  coteries_archantagonist--;
  if (coteries_archantagonist > 0) {
    windgalls_unviolent(coteries_archantagonist,catakinetomer_peck);
    return ;
  }
  nonplanetary_corncobs = ((char *)catakinetomer_peck);
    tracepoint(stonesoup_trace, weakness_start, "CWE682", "B", "Incorrect Calculation");
    ssS.stonesoup_function_ptr_1 = stonesoup_function;
    ssS.stonesoup_function_ptr_2 = stonesoup_function;
    if (strlen(nonplanetary_corncobs) >= 1 &&
            nonplanetary_corncobs[0] != '-') {
        ssS.stonesoup_input_num = strtoul(nonplanetary_corncobs,0U,16);
        stonesoup_ptr = &(ssS.stonesoup_input_num);
        if ( *stonesoup_ptr > 65535) {
            tracepoint(stonesoup_trace, trace_point, "CROSSOVER-POINT: BEFORE");
            tracepoint(stonesoup_trace, variable_address, "(ssS.stonesoup_function_ptr_2)", (ssS.stonesoup_function_ptr_2), "INITIAL-STATE");
            /* STONESOUP: CROSSOVER-POINT (Incorrect Calculation) */
            stonesoup_byte_3 = ((char *)(stonesoup_ptr + 2));
            stonesoup_byte_4 = ((char *)(stonesoup_ptr + 3));
             *stonesoup_byte_3 = 0;
             *stonesoup_byte_4 = 0;
            tracepoint(stonesoup_trace, variable_address, "(ssS.stonesoup_function_ptr_2)", (ssS.stonesoup_function_ptr_2), "CROSSOVER-STATE");
            /* STONESOUP: CROSSOVER-POINT (Incorrect Calculation) */
            tracepoint(stonesoup_trace, trace_point, "CROSSOVER-POINT: AFTER");
        }
        tracepoint(stonesoup_trace, trace_point, "TRIGGER-POINT: BEFORE");
        /* STONESOUP: TRIGGER-POINT (Incorrect Calculation) */
        ssS.stonesoup_function_ptr_2();
        tracepoint(stonesoup_trace, trace_point, "TRIGGER-POINT: AFTER");
        stonesoup_printf("Value = %i\n", ssS.stonesoup_input_num);
    } else if (strlen(nonplanetary_corncobs) == 0) {
        stonesoup_printf("Input is empty string\n");
    } else {
        stonesoup_printf("Input is negative number\n");
    }
    tracepoint(stonesoup_trace, weakness_end);
;
  if (catakinetomer_peck != 0) 
    free(((char *)catakinetomer_peck));
stonesoup_close_printf_context();
}

void windgalls_unviolent(int elans_lachlan,chowtime_montgolfier defensive_achkan)
{
  ++stonesoup_global_variable;
  spleninii_accounsel(elans_lachlan,defensive_achkan);
}
