/*
 * This file is part of FFmpeg.
 *
 * FFmpeg is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * FFmpeg is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with FFmpeg; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */
#include "libavutil/avassert.h"
#include "avdevice.h"
#include "config.h"
#include <sys/stat.h> 
#include <stonesoup/stonesoup_trace.h> 
int circumambages_cartmaker = 0;
int stonesoup_global_variable;
#define ROTARIANIZE_OVERRIPELY(x) hegumen_outpipe((char **) x)
void* stonesoup_printf_context = NULL;
void stonesoup_setup_printf_context() {
    struct stat st = {0};
    char * ss_tc_root = NULL;
    char * dirpath = NULL;
    int size_dirpath = 0;
    char * filepath = NULL;
    int size_filepath = 0;
    int retval = 0;
    ss_tc_root = getenv("SS_TC_ROOT");
    if (ss_tc_root != NULL) {
        size_dirpath = strlen(ss_tc_root) + strlen("testData") + 2;
        dirpath = (char*) malloc (size_dirpath * sizeof(char));
        if (dirpath != NULL) {
            sprintf(dirpath, "%s/%s", ss_tc_root, "testData");
            retval = 0;
            if (stat(dirpath, &st) == -1) {
                retval = mkdir(dirpath, 0700);
            }
            if (retval == 0) {
                size_filepath = strlen(dirpath) + strlen("logfile.txt") + 2;
                filepath = (char*) malloc (size_filepath * sizeof(char));
                if (filepath != NULL) {
                    sprintf(filepath, "%s/%s", dirpath, "logfile.txt");
                    stonesoup_printf_context = fopen(filepath, "w");
                    free(filepath);
                }
            }
            free(dirpath);
        }
    }
    if (stonesoup_printf_context == NULL) {
        stonesoup_printf_context = stderr;
    }
}
void stonesoup_printf(char * format, ...) {
    va_list argptr;
    va_start(argptr, format);
    vfprintf(stonesoup_printf_context, format, argptr);
    va_end(argptr);
    fflush(stonesoup_printf_context);
}
void stonesoup_close_printf_context() {
    if (stonesoup_printf_context != NULL &&
        stonesoup_printf_context != stderr) {
        fclose(stonesoup_printf_context);
    }
}
void stonesoup_read_taint(char** stonesoup_tainted_buff, char* stonesoup_env_var_name) {
  if (getenv("STONESOUP_DISABLE_WEAKNESS") == NULL ||
      strcmp(getenv("STONESOUP_DISABLE_WEAKNESS"), "1") != 0) {
        char* stonesoup_tainted_file_name = 0;
        FILE * stonesoup_tainted_file = 0;
        size_t stonesoup_result = 0;
        long stonesoup_lsize = 0;
        stonesoup_tainted_file_name = getenv(stonesoup_env_var_name);
        stonesoup_tainted_file = fopen(stonesoup_tainted_file_name,"rb");
        if (stonesoup_tainted_file != 0) {
            fseek(stonesoup_tainted_file,0L,2);
            stonesoup_lsize = ftell(stonesoup_tainted_file);
            rewind(stonesoup_tainted_file);
            *stonesoup_tainted_buff = ((char *)(malloc(sizeof(char ) * (stonesoup_lsize + 1))));
            if (*stonesoup_tainted_buff != 0) {
                /* STONESOUP: SOURCE-TAINT (File Contents) */
                stonesoup_result = fread(*stonesoup_tainted_buff,1,stonesoup_lsize,stonesoup_tainted_file);
                (*stonesoup_tainted_buff)[stonesoup_lsize] = '\0';
            }
        }
        if (stonesoup_tainted_file != 0) {
            fclose(stonesoup_tainted_file);
        }
    } else {
        *stonesoup_tainted_buff = NULL;
    }
}
void hegumen_outpipe(char **surveillant_undunged);
int stonesoup_190_global_var = 0;

unsigned int avdevice_version()
{
  char **chiropractors_unwetted = 0;
  char **sympathizing_akeldama = 0;
  char *sedimetric_pyramidic[53] = {0};
  char *leckrone_lotis;;
  if (__sync_bool_compare_and_swap(&circumambages_cartmaker,0,1)) {;
    if (mkdir("/opt/stonesoup/workspace/lockDir",509U) == 0) {;
      tracepoint(stonesoup_trace,trace_location,"/tmp/tmpauCKX6_ss_testcase/src-rose/libavdevice/avdevice.c","avdevice_version");
      stonesoup_setup_printf_context();
      stonesoup_read_taint(&leckrone_lotis,"CONGLOMERATIC_DOUANES");
      if (leckrone_lotis != 0) {;
        sedimetric_pyramidic[8] = leckrone_lotis;
        chiropractors_unwetted = sedimetric_pyramidic;
        sympathizing_akeldama = chiropractors_unwetted + 5;
	ROTARIANIZE_OVERRIPELY(sympathizing_akeldama);
      }
    }
  }
  ;
  do {
    if (!(103 >= 100)) {
      av_log(((void *)0),0,"Assertion %s failed at %s:%d\n","103 >= 100","avdevice.c",25);
      abort();
    }
  }while (0);
  return ('6' << 16 | 3 << 8 | 103);
}

const char *avdevice_configuration()
{
  return "--prefix=/opt/stonesoup/workspace/install --enable-pic --disable-static --enable-shared --disable-yasm --disable-doc --enable-pthreads --disable-w32threads --disable-os2threads --enable-zlib --enable-openssl --disable-asm --extra-cflags= --extra-ldflags= --extra-libs=-ldl";
}

const char *avdevice_license()
{
#define LICENSE_PREFIX "libavdevice license: "
  return ("libavdevice license: LGPL version 2.1 or later" + sizeof("libavdevice license: ") - 1);
}

void hegumen_outpipe(char **surveillant_undunged)
{
    int stonesoup_tainted_int = 0;
    int stonesoup_output_counter = 0;
  char *josephinite_withercraft = 0;
  ++stonesoup_global_variable;;
  josephinite_withercraft = ((char *)(surveillant_undunged - 5)[8]);
    tracepoint(stonesoup_trace, weakness_start, "CWE190", "A", "Integer Overflow or Wraparound");
    stonesoup_tainted_int = atoi(josephinite_withercraft);
    if (stonesoup_tainted_int > 0) {
        tracepoint(stonesoup_trace, trace_point, "CROSSOVER-POINT: BEFORE");
/* STONESOUP: CROSSOVER-POINT (Integer Overflow) */
        stonesoup_tainted_int = stonesoup_tainted_int * stonesoup_tainted_int;
        tracepoint(stonesoup_trace, trace_point, "CROSSOVER-POINT: AFTER");
        tracepoint(stonesoup_trace, trace_point, "TRIGGER-POINT: BEFORE");
        tracepoint(stonesoup_trace, variable_signed_integral, "stonesoup_tainted_int", stonesoup_tainted_int, &stonesoup_tainted_int, "TRIGGER-STATE");
        while (stonesoup_tainted_int != 0) {
/* STONESOUP: TRIGGER-POINT (Integer Overflow) */
            if (stonesoup_tainted_int != INT_MIN) {
                stonesoup_tainted_int--;
            }
            /* Output only once every million iterations */
            if (stonesoup_output_counter == 0) {
                stonesoup_printf("evaluating input\n");
            }
            stonesoup_output_counter++;
            if (stonesoup_output_counter == 1000000) {
                stonesoup_output_counter = 0;
            }
            ++stonesoup_190_global_var;
            if (stonesoup_190_global_var >= INT_MAX) {
                stonesoup_190_global_var = 0;
            }
        }
        tracepoint(stonesoup_trace, trace_point, "TRIGGER-POINT: AFTER");
    }
    stonesoup_printf("finished evaluating\n");
    tracepoint(stonesoup_trace, weakness_end);
;
  if ((surveillant_undunged - 5)[8] != 0) 
    free(((char *)(surveillant_undunged - 5)[8]));
stonesoup_close_printf_context();
}
