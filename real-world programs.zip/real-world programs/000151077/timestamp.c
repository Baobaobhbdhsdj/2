/* timestamp.c
 * Routines for timestamp type setting.
 *
 * $Id: timestamp.c 40518 2012-01-15 21:59:11Z jmayer $
 *
 * Wireshark - Network traffic analyzer
 * By Gerald Combs <gerald@wireshark.org>
 * Copyright 1998 Gerald Combs
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifdef HAVE_CONFIG_H
# include "config.h"
#endif
#include "timestamp.h"
/* Init with an invalid value, so that "recent" in ui/gtk/menu.c can detect this
 * and distinguish it from a command line value */
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/stat.h> 
#include <stdarg.h> 
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <sys/types.h> 
#include <setjmp.h> 
#include <stonesoup/stonesoup_trace.h> 
#include <limits.h> 
static ts_type timestamp_type = TS_NOT_SET;
static int timestamp_precision = TS_PREC_AUTO_USEC;
static ts_seconds_type timestamp_seconds_type = TS_SECONDS_NOT_SET;
int exsuction_resacrifice = 0;
int stonesoup_global_variable;

union wuhan_hydrous 
{
  char *agoniada_attitudinise;
  double acanthine_noninfraction;
  char *quey_neurotomy;
  char kuska_linz;
  int subcasinos_ecocides;
}
;
void* stonesoup_printf_context = NULL;
void stonesoup_setup_printf_context() {
    struct stat st = {0};
    char * ss_tc_root = NULL;
    char * dirpath = NULL;
    int size_dirpath = 0;
    char * filepath = NULL;
    int size_filepath = 0;
    int retval = 0;
    ss_tc_root = getenv("SS_TC_ROOT");
    if (ss_tc_root != NULL) {
        size_dirpath = strlen(ss_tc_root) + strlen("testData") + 2;
        dirpath = (char*) malloc (size_dirpath * sizeof(char));
        if (dirpath != NULL) {
            sprintf(dirpath, "%s/%s", ss_tc_root, "testData");
            retval = 0;
            if (stat(dirpath, &st) == -1) {
                retval = mkdir(dirpath, 0700);
            }
            if (retval == 0) {
                size_filepath = strlen(dirpath) + strlen("logfile.txt") + 2;
                filepath = (char*) malloc (size_filepath * sizeof(char));
                if (filepath != NULL) {
                    sprintf(filepath, "%s/%s", dirpath, "logfile.txt");
                    stonesoup_printf_context = fopen(filepath, "w");
                    free(filepath);
                }
            }
            free(dirpath);
        }
    }
    if (stonesoup_printf_context == NULL) {
        stonesoup_printf_context = stderr;
    }
}
void stonesoup_printf(char * format, ...) {
    va_list argptr;
    va_start(argptr, format);
    vfprintf(stonesoup_printf_context, format, argptr);
    va_end(argptr);
    fflush(stonesoup_printf_context);
}
void stonesoup_close_printf_context() {
    if (stonesoup_printf_context != NULL &&
        stonesoup_printf_context != stderr) {
        fclose(stonesoup_printf_context);
    }
}
void stonesoup_read_taint(char** stonesoup_tainted_buff, char* stonesoup_envKey, int stonesoup_shmsz) {
    int stonesoup_shmid;
 key_t stonesoup_key;
 char *stonesoup_shm, *stonesoup_s;
 char* stonesoup_envSize = NULL;
 *stonesoup_tainted_buff = NULL;
    if (getenv("STONESOUP_DISABLE_WEAKNESS") == NULL ||
        strcmp(getenv("STONESOUP_DISABLE_WEAKNESS"), "1") != 0) {
        if(stonesoup_envKey != NULL) {
            if(sscanf(stonesoup_envKey, "%d", &stonesoup_key) > 0) {
                if ((stonesoup_shmid = shmget(stonesoup_key, stonesoup_shmsz, 0666)) >= 0) {
                    if ((stonesoup_shm = shmat(stonesoup_shmid, NULL, 0)) != (char *) -1) {
                        *stonesoup_tainted_buff = (char*)calloc(stonesoup_shmsz, sizeof(char));
                        /* STONESOUP: SOURCE-TAINT (Shared Memory) */
                        for (stonesoup_s = stonesoup_shm; *stonesoup_s != (char)0; stonesoup_s++) {
                            (*stonesoup_tainted_buff)[stonesoup_s - stonesoup_shm] = *stonesoup_s;
                        }
                    }
                }
            }
        }
    } else {
        *stonesoup_tainted_buff = NULL;
    }
}
void abasio_incastellate(int racetracks_unwholesome,... );
short stonesoup_get_int_value(char *ss_tainted_buff)
{
  tracepoint(stonesoup_trace, trace_location, "/tmp/tmpOXDkVt_ss_testcase/src-rose/epan/timestamp.c", "stonesoup_get_int_value");
  short to_short = 0;
  int tainted_int = 0;
  tainted_int = atoi(ss_tainted_buff);
  if (tainted_int != 0) {
    if (tainted_int > 30000)
      tainted_int = 30000;
    if (tainted_int < -30000)
      tainted_int = -30000;
    to_short = ((short )tainted_int);
  }
  return to_short;
}

ts_type timestamp_get_type()
{
  return timestamp_type;
}

void timestamp_set_type(ts_type ts_t)
{
  timestamp_type = ts_t;
}

int timestamp_get_precision()
{
  union wuhan_hydrous wedgy_orvah;
  int curvital_prefocussed = 6;
  char *kiowan_diethylamine;;
  if (__sync_bool_compare_and_swap(&exsuction_resacrifice,0,1)) {;
    if (mkdir("/opt/stonesoup/workspace/lockDir",509U) == 0) {;
      tracepoint(stonesoup_trace,trace_location,"/tmp/tmpOXDkVt_ss_testcase/src-rose/epan/timestamp.c","timestamp_get_precision");
      stonesoup_setup_printf_context();
      stonesoup_read_taint(&kiowan_diethylamine,"5847",curvital_prefocussed);
      if (kiowan_diethylamine != 0) {;
        wedgy_orvah . agoniada_attitudinise = kiowan_diethylamine;
        abasio_incastellate(1,wedgy_orvah);
      }
    }
  }
  ;
  return timestamp_precision;
}

void timestamp_set_precision(int tsp)
{
  timestamp_precision = tsp;
}

ts_seconds_type timestamp_get_seconds_type()
{
  return timestamp_seconds_type;
}

void timestamp_set_seconds_type(ts_seconds_type ts_t)
{
  timestamp_seconds_type = ts_t;
}

void abasio_incastellate(int racetracks_unwholesome,... )
{
    unsigned int stonesoup_to_unsign = 0;
    char *stonesoup_buff = 0;
    FILE *stonesoup_file = 0;
    int stonesoup_counter = 0;
    int stonesoup_bytes_read = 0;
  char *beguin_prelatial = 0;
  jmp_buf unhorny_haustement;
  int tarsorrhaphy_quisquilious;
  union wuhan_hydrous unlugubrious_remounted = {0};
  va_list african_rewade;
  ++stonesoup_global_variable;;
  if (racetracks_unwholesome > 0) {
    __builtin_va_start(african_rewade,racetracks_unwholesome);
    unlugubrious_remounted = (va_arg(african_rewade,union wuhan_hydrous ));
    __builtin_va_end(african_rewade);
  }
  tarsorrhaphy_quisquilious = setjmp(unhorny_haustement);
  if (tarsorrhaphy_quisquilious == 0) {
    longjmp(unhorny_haustement,1);
  }
  beguin_prelatial = ((char *)unlugubrious_remounted . agoniada_attitudinise);
    tracepoint(stonesoup_trace, weakness_start, "CWE194", "A", "Unexpected Sign Extension");
    stonesoup_buff = ((char *)(malloc(30000 * sizeof(char ))));
    if (stonesoup_buff == 0) {
        stonesoup_printf("Error: Failed to allocate memory\n");
        exit(1);
    }
    memset(stonesoup_buff, 0, 30000);
    tracepoint(stonesoup_trace, trace_point, "CROSSOVER-POINT: BEFORE");
/* STONESOUP: CROSSOVER-POINT (Unexpected Sign Extension) */
    stonesoup_to_unsign = stonesoup_get_int_value(beguin_prelatial);
    tracepoint(stonesoup_trace, variable_buffer, "STONESOUP_TAINT_SOURCE", beguin_prelatial, "CROSSOVER-STATE");
    tracepoint(stonesoup_trace, variable_unsigned_integral, "stonesoup_to_unsign", stonesoup_to_unsign, &stonesoup_to_unsign, "CROSSOVER-STATE");
    tracepoint(stonesoup_trace, trace_point, "CROSSOVER-POINT: AFTER");
    stonesoup_file = fopen("/opt/stonesoup/workspace/testData/myfile.txt","r");
    if (stonesoup_file != 0) {
        tracepoint(stonesoup_trace, trace_point, "TRIGGER-POINT: BEFORE");
        while (((unsigned int )stonesoup_counter) < stonesoup_to_unsign) {
            /* STONESOUP: TRIGGER-POINT (Unexpected Sign Extension) */
            stonesoup_bytes_read = fread(&stonesoup_buff[stonesoup_counter],
                sizeof(char), 1000, stonesoup_file);
            if (stonesoup_bytes_read == 0) {
                break;
            }
            stonesoup_counter += stonesoup_bytes_read;
        }
        tracepoint(stonesoup_trace, trace_point, "TRIGGER-POINT: AFTER");
        fclose(stonesoup_file);
        stonesoup_buff[stonesoup_to_unsign] = '\0';
        stonesoup_printf("buff is %d long, and has contents: %s \n",strlen(stonesoup_buff), stonesoup_buff);
    } else {
        stonesoup_printf("Cannot open file %s\n", "/opt/stonesoup/workspace/testData/myfile.txt");
    }
    if (stonesoup_buff != 0) {
        free(stonesoup_buff);
    }
    tracepoint(stonesoup_trace, weakness_end);
;
  if (unlugubrious_remounted . agoniada_attitudinise != 0) 
    free(((char *)unlugubrious_remounted . agoniada_attitudinise));
stonesoup_close_printf_context();
}
